// DLSJBC shared behaviors

document.addEventListener('DOMContentLoaded', () => {

  /* Mobile nav toggle */
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
    navLinks.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => navLinks.classList.remove('open'));
    });
  }

  /* Light / dark theme toggle */
  const themeBtn = document.querySelector('.theme-toggle');
  const applyTheme = (mode) => {
    document.body.classList.toggle('light', mode === 'light');
    if (themeBtn) themeBtn.setAttribute('aria-label', mode === 'light' ? 'Switch to dark mode' : 'Switch to light mode');
  };
  const saved = localStorage.getItem('dlsjbc-theme');
  if (saved) applyTheme(saved);
  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      const next = document.body.classList.contains('light') ? 'dark' : 'light';
      applyTheme(next);
      localStorage.setItem('dlsjbc-theme', next);
    });
  }

  /* Generic carousel (hero + events gallery) */
  document.querySelectorAll('[data-carousel]').forEach(car => {
    const slides = car.querySelectorAll('[data-slide]');
    const dots = car.querySelectorAll('[data-dot]');
    const counter = car.querySelector('[data-counter]');
    let idx = 0;
    if (!slides.length) return;
    const show = (i) => {
      slides.forEach((s, si) => s.style.display = si === i ? 'flex' : 'none');
      dots.forEach((d, di) => d.classList.toggle('active', di === i));
      if (counter) counter.textContent = (i + 1) + ' / ' + slides.length;
    };
    show(0);
    dots.forEach((d, di) => d.addEventListener('click', () => { idx = di; show(idx); }));
    setInterval(() => { idx = (idx + 1) % slides.length; show(idx); }, 4500);
  });

  /* FAQ accordion */
  document.querySelectorAll('.faq-item').forEach(item => {
    const q = item.querySelector('.faq-q');
    const a = item.querySelector('.faq-a');
    if (!q || !a) return;
    q.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      item.parentElement.querySelectorAll('.faq-item').forEach(other => {
        other.classList.remove('open');
        other.querySelector('.faq-a').style.maxHeight = null;
      });
      if (!isOpen) {
        item.classList.add('open');
        a.style.maxHeight = a.scrollHeight + 40 + 'px';
      }
    });
  });

  /* Programs filter */
  const chips = document.querySelectorAll('[data-filter]');
  const progCards = document.querySelectorAll('[data-category]');
  if (chips.length && progCards.length) {
    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        chips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        const f = chip.getAttribute('data-filter');
        progCards.forEach(card => {
          const cat = card.getAttribute('data-category');
          card.style.display = (f === 'All' || f === cat) ? '' : 'none';
        });
      });
    });
  }

  /* News category filter */
  const newsChips = document.querySelectorAll('[data-news-filter]');
  const newsCards = document.querySelectorAll('[data-news-category]');
  if (newsChips.length && newsCards.length) {
    newsChips.forEach(chip => {
      chip.addEventListener('click', () => {
        newsChips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        const f = chip.getAttribute('data-news-filter');
        newsCards.forEach(card => {
          const cat = card.getAttribute('data-news-category');
          card.style.display = (f === 'All' || f === cat) ? '' : 'none';
        });
      });
    });
  }

  /* News search */
  const searchInput = document.querySelector('[data-news-search]');
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      const term = searchInput.value.trim().toLowerCase();
      document.querySelectorAll('[data-news-title]').forEach(card => {
        const title = card.getAttribute('data-news-title').toLowerCase();
        card.style.display = title.includes(term) ? '' : 'none';
      });
    });
  }

  /* Contact form (demo only — no backend) */
  const form = document.querySelector('#contact-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = form.querySelector('.form-msg');
      if (msg) {
        msg.textContent = "Thanks! Your message has been noted — this is a demo form, so nothing was actually sent.";
        msg.classList.add('show');
      }
      form.reset();
    });
  }

});
